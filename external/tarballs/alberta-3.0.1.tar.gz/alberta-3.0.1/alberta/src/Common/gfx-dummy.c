/* foo, or maybe even bar */


/* This function serves the sole purpose to have one defined symbol
 * that a linker can check for, even if all other graphics stuff is
 * not there.
 */
void alberta_gfx_initialize()
{

}

